import { Partido } from './partido.model';

describe('Partido', () => {
  it('should create an instance', () => {
    expect(new Partido()).toBeTruthy();
  });
});
