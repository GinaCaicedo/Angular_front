import { Resultado } from './resultado.model';

describe('Resultado', () => {
  it('should create an instance', () => {
    expect(new Resultado()).toBeTruthy();
  });
});
