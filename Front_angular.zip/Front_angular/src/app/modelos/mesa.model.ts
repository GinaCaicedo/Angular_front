export class Mesa {
    _id?: string;
    numero?: string;
    cantidad_inscritos?: string;
    mesa?: string;
}
