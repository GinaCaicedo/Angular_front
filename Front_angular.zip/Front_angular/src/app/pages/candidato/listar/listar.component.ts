import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import Swal from 'sweetalert2';
import { CandidatoService } from '../../../servicios/candidato.service';

@Component({
  selector: 'ngx-listar',
  templateUrl: './listar.component.html',
  styleUrls: ['./listar.component.scss']
})
export class ListarComponent implements OnInit {

  nombreColumnas = ['Cedula','numero_resolucion', 'Nombre', 'Apellidos', 'Opciones'];
  listadoCandidatos = [];

  constructor(private miServicioCandidatos: CandidatoService,
    private router: Router) { }

  ngOnInit(): void {
    this.buscarTodosLosCandidatos();
  }
 
  buscarTodosLosCandidatos(){
    this.miServicioCandidatos.buscarTodosLosCandidatos().subscribe(
      data=>{
        this.listadoCandidatos=data;
      }
    );
  }


 
  crearCandidato() {
    this.router.navigateByUrl("pages/candidato/crear");
  }

  actualizarCandidato(idCandidato: string) {
    this.router.navigateByUrl("pages/candidato/actualizar/"+idCandidato);
  }

  eliminarCandidato(idCandidato: string) {

    Swal.fire({
      title: 'Eliminar Candidato',
      text: "Seguro que desea eliminar el candidato?",
      icon: 'warning',
      showCancelButton: true,
      confirmButtonColor: '#3085d6',
      cancelButtonColor: '#d33',
      confirmButtonText: 'Si, eliminarlo!'
    }).then((result) => {
      if (result.isConfirmed) {
        this.miServicioCandidatos.eliminarCandidato(idCandidato).subscribe(
          data => {
            Swal.fire({
              icon: 'success',
              title: 'Candidato eliminado correctamente',
              showConfirmButton: true
            })
            this.buscarTodosLosCandidatos();
          }
        );
      }
    })   
  }
}