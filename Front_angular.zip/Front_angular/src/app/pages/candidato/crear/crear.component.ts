import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import Swal from 'sweetalert2';
import { Candidato } from '../../../modelos/candidato.model';
import { CandidatoService } from '../../../servicios/candidato.service';

@Component({
  selector: 'ngx-crear',
  templateUrl: './crear.component.html',
  styleUrls: ['./crear.component.scss']
})
export class CrearComponent implements OnInit {
  modoCreacion: boolean = true;
  intentoEnvio: boolean = false;
  id_Candidato:string;
  infoCandidato: Candidato = {
    cedula: "",
    numero_resolucion:"",
    nombre: "",
    apellido: ""
  }
  router: any;

  constructor(private miServicioCandidato: CandidatoService,
    private rutaActual: ActivatedRoute) { }
    
  ngOnInit(): void {
    
    if(this.rutaActual.snapshot.params.id_candidato){
      this.modoCreacion = false;
      this.miServicioCandidato.buscarCandidatoPorId(this.rutaActual.snapshot.params.id_candidato)
      .subscribe(data=>{
            this.infoCandidato=data;}
            );
      } else {
        this.modoCreacion = true;
      }
    }

  buscarCandidato(idCandidato: string) {
    this.miServicioCandidato.buscarCandidatoPorId(idCandidato)
    .subscribe(
      data => {
        this.infoCandidato = data;
      }
    );
  }

  actualizarCandidato() {
    if(this.validarCampos()) {
      this.miServicioCandidato.actualizarCandidato(this.infoCandidato)
      .subscribe(
        data => {
          Swal.fire({
            icon: 'success',
            title: 'Candidato Actualizado!',
            showConfirmButton: true
          })

          this.router.navigateByUrl(["pages/candidato/listar"]);
        }
      );
    }
  }

  crearCandidato() {
    if(this.validarCampos()) {
      this.miServicioCandidato.crearCandidato(this.infoCandidato)
      .subscribe(
        data => {
          Swal.fire({
            icon: 'success',
            title: 'Candidato Creado!',
            showConfirmButton: true
          })

          this.router.navigateByUrl("pages/candidato/listar");
        }
      );
    }    
  }

  validarCampos(): boolean {
    this.intentoEnvio = true;
    if(this.infoCandidato.cedula == "" || this.infoCandidato.nombre == "" || this.infoCandidato.apellido == "") {
      return false;
    } else {
      return true;
    }
  }

}