import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { SubscribeOnObservable } from 'rxjs/internal-compatibility';
import Swal from 'sweetalert2';
import { Candidato } from '../../../modelos/candidato.model';
import { Mesa } from '../../../modelos/mesa.model';
import { Resultado } from '../../../modelos/resultado.model';
import { CandidatoService } from '../../../servicios/candidato.service';
import { MesaService } from '../../../servicios/mesa.service';
import { ResultadoService } from '../../../servicios/resultado.service';

@Component({
  selector: 'ngx-crear',
  templateUrl: './crear.component.html',
  styleUrls: ['./crear.component.scss']
})
export class CrearComponent implements OnInit {


  modoCreacion: boolean = true;
  intentoEnvio: boolean = false;
  listadoCandidatos: Candidato[] = [];
  listadoMesas: Mesa[] = [];

  infoResultado: Resultado = {
    numero_votos: "",
    candidato:{},
    mesa:{}
  }

  constructor(private miServicioResultado : ResultadoService, 
    private miServicioCandidato: CandidatoService, 
    private miServicioMesa: MesaService, 
    private rutaActual : ActivatedRoute,
     private router : Router) { }

  ngOnInit(): void {
    
    if(this.rutaActual.snapshot.params.id_resultado){
      this.modoCreacion = false;
      this.buscarResultado(this.rutaActual.snapshot.params.id_resultado);
    } else {
      this.modoCreacion = true;
     }
    
  }

  buscarResultado(idresultado : string){
    this.miServicioResultado.buscarResultadoId(idresultado)
      .subscribe(
        data => {
          this.infoResultado = data;
        }
      );
  }

  actualizarResultado(){

    if ( this.validarCampos()) {
      this.miServicioResultado.actualizarResultado(this.infoResultado)
    .subscribe(
      data => {
        Swal.fire({
          icon: 'success',
          title: 'Resultado actualizado Satisfactoriamente',
          showConfirmButton: true
        })
        
        this.router.navigateByUrl("pages/resultado/listar");
      }
    );
      
    }

    
  }

  crearResultado() {
    console.log(this.infoResultado)

    if ( this.validarCampos()) {
      this.miServicioResultado.crearResultado(this.infoResultado)
      .subscribe (
        data => {
          Swal.fire({
            icon: 'success',
            title: 'Resultado creado Satisfactoriamente',
            showConfirmButton: true
          })
          
          this.router.navigateByUrl("pages/resultado/listar");
        }
      );

    }
  }

  validarCampos (): boolean {
    this.intentoEnvio = true;
    console.log(this.infoResultado)
    if (this.infoResultado.numero_votos == ""){
      return false;
    } else {
      return true;
    }
  }


  buscarTodosLosCandidatos() {
    this.miServicioCandidato.buscarTodosLosCandidatos().subscribe(
      data => {
        this.listadoCandidatos = data;
      }
    );
  }

    buscarTodasLasMesas() {
      this.miServicioMesa.buscarMesa().subscribe(
        data => {
          this.listadoMesas = data;
        }
      );
 
  }
}
