import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { ResultadoRoutingModule } from './resultado-routing.module';
import { FormsModule } from '@angular/forms';
import { NbCardModule } from '@nebular/theme';
import { BorrarComponent } from './borrar/borrar.component';
import { ListarComponent } from './listar/listar.component';
import { CrearComponent } from './crear/crear.component';
import { ActualizarComponent } from './actualizar/actualizar.component';


@NgModule({
  declarations: [
    BorrarComponent,
    ListarComponent,
    CrearComponent,
    ActualizarComponent
  ],
  imports: [
    CommonModule,
    ResultadoRoutingModule,
    NbCardModule,
    FormsModule
  ]
})
export class ResultadoModule { }
