import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import Swal from 'sweetalert2';
import { ResultadoService } from '../../../servicios/resultado.service';

@Component({
  selector: 'ngx-listar',
  templateUrl: './listar.component.html',
  styleUrls: ['./listar.component.scss']
})
export class ListarComponent implements OnInit {

  nombreColumnas = ["numero_votos", "cedula","numero","Opciones"];
  listadoResultado = [];

  constructor(private miServicioResultado: ResultadoService,
    private router: Router) { }

  ngOnInit(): void {
    this.buscarResultado();
  }

  buscarResultado() {
    this.miServicioResultado.buscarResultado().subscribe(
      data => {
        this.listadoResultado = data;
      }
    );
  }

  crearResultado(){
    this.router.navigateByUrl("pages/resultado/crear");
  }

  actualizarResultado(idResultado: string) {
    console.log("editando"+idResultado)
    this.router.navigateByUrl("pages/resultado/actualizar/"+idResultado);
  }

  eliminarResultado(idResultado: string) {
    Swal.fire({
      title: 'Eliminar MESA',
      text: "Seguro que desea eliminar el resultado?",
      icon: 'warning',
      showCancelButton: true,
      confirmButtonColor: '#276DD1',
      cancelButtonColor: '#d33',
      confirmButtonText: 'Si, eliminar!'
    }).then((result) => {
      if (result.isConfirmed) {
        this.miServicioResultado.eliminarResultado(idResultado).subscribe(
  
          data => {
            Swal.fire({
              icon: 'success',
              title: 'Resultado eliminada',
              showConfirmButton: true
            })
    
            this.buscarResultado();
    
          }
        );
      }
    })    
  }
}