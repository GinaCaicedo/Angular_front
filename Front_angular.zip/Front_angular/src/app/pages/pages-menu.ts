import { NbMenuItem } from '@nebular/theme';

export const MENU_ITEMS: NbMenuItem[] = [


  {
    title: 'Administracion Registraduria',
    group: true,
  },
  {
    title: 'Administracion Registraduria',
    icon: 'layout-outline',
    children: [
      {
        title: 'Mesa Listar',
        link: '/pages/mesa/listar',
      },
      {
        title: 'Mesa Administrar',
        link: '/pages/mesa/crear',
      },
      {
        title: 'Partido Listar',
        link: '/pages/partido/listar',
      },
      {
        title: 'Partido Administrar',
        link: '/pages/partido/crear',
      },


      {
        title: 'Candidato Administrar',
        link: '/pages/candidato/crear',
      },


      {
        title: 'Candidato Listar',
        link: '/pages/candidato/listar',
      },


      {
        title: 'Resultado Administrar',
        link: '/pages/resultado/crear',
      },


      {
        title: 'Resultado Listar',
        link: '/pages/resultado/listar',
      },

    ],
  },
  
  {
    title: 'Autorización',
    icon: 'lock-outline',
    children: [
      {
        title: 'Login',
        link: 'seguridad/login',
      },

    ],
  },
];
