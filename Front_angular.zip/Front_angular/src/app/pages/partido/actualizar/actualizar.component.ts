import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'ngx-actualizar',
  templateUrl: './actualizar.component.html',
  styleUrls: ['./actualizar.component.scss']
})
export class ActualizarComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
