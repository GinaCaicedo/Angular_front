import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import Swal from 'sweetalert2';
import { Partido } from '../../../modelos/partido.model';
import { PartidoService } from '../../../servicios/partido.service';


@Component({
  selector: 'ngx-crear',
  templateUrl: './crear.component.html',
  styleUrls: ['./crear.component.scss']
})
export class CrearComponent implements OnInit {
  modoCreacion: boolean = true;
  intentoEnvio: boolean = false;
  infoPartido: Partido = {
    nombre: "",
    lema: ""
  }
  router: any;

  constructor(private miServicioPartido: PartidoService,
    private rutaActual: ActivatedRoute ) { }

  ngOnInit(): void {
    
    if(this.rutaActual.snapshot.params.id_partido){
      this.modoCreacion = false;
      this.miServicioPartido.buscarPartidoId(this.rutaActual.snapshot.params.id_partido)
      .subscribe(
        data=>{
          this.infoPartido=data;}
          );
    } else {
      this.modoCreacion = true;
    }
  }

  buscarPartido(idPartido: string) {
    this.miServicioPartido.buscarPartidoId(idPartido)
    .subscribe(
      data => {
        this.infoPartido = data;
      }
    );
  }

  actualizarPartido() {
    if(this.validarCampos()) {
      this.miServicioPartido.actualizarPartido(this.infoPartido)
      .subscribe(
        data => {
          Swal.fire({
            icon: 'success',
            title: 'Partido Actualizado!',
            showConfirmButton: true
          })

          this.router.navigateByUrl("pages/partido/listar");
        }
      );
    }
  }

  crearPartido() {
    if(this.validarCampos()) {
      this.miServicioPartido.crearPartido(this.infoPartido)
      .subscribe(
        data => {
          Swal.fire({
            icon: 'success',
            title: 'Partido Creado!',
            showConfirmButton: true
          })

          this.router.navigateByUrl("pages/partido/listar");
        }
      );
    }    
  }

  validarCampos(): boolean {
    this.intentoEnvio = true;
    if(this.infoPartido.lema == "" || this.infoPartido.nombre== "") 
    {
      return false;
    } else {
      return true;
    }
  }
}
