import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { PartidoRoutingModule } from './partido-routing.module';
import { FormsModule } from '@angular/forms';
import { NbCardModule } from '@nebular/theme';
import { ListarComponent } from './listar/listar.component';
import { CrearComponent } from './crear/crear.component';
import { BorrarComponent } from './borrar/borrar.component';
import { ActualizarComponent } from './actualizar/actualizar.component';


@NgModule({
  declarations: [
    ListarComponent,
    CrearComponent,
    BorrarComponent,
    ActualizarComponent
  ],
  imports: [
    CommonModule,
    PartidoRoutingModule,
    NbCardModule,
    FormsModule
  ]
})
export class PartidoModule { }
