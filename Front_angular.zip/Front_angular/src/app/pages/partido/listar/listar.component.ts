import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import Swal from 'sweetalert2';
import { PartidoService } from '../../../servicios/partido.service';

@Component({
  selector: 'ngx-listar',
  templateUrl: './listar.component.html',
  styleUrls: ['./listar.component.scss']
})
export class ListarComponent implements OnInit {

  nombreColumnas = ["nombre", "lema", "Opciones"];
  listadoPartido = [];

  constructor(private miServicioPartido: PartidoService,
    private router: Router) { }

  ngOnInit(): void {
    this.buscarPartido();
  }

  buscarPartido() {
    this.miServicioPartido.buscarPartido().subscribe(
      data => {
        this.listadoPartido = data;
      }
    );
  }

  crearPartido(){
    this.router.navigateByUrl("pages/partido/crear");
  }
  actualizarPartido(idPartido: string) {

    this.router.navigateByUrl("pages/partido/actualizar/"+idPartido);
  }

  eliminarPartido(idPartido: string) {
    Swal.fire({
      title: 'Eliminar Partido',
      text: "Seguro que desea eliminar el partido?",
      icon: 'warning',
      showCancelButton: true,
      confirmButtonColor: '#276DD1',
      cancelButtonColor: '#d33',
      confirmButtonText: 'Si, eliminar!'
    }).then((result) => {
      if (result.isConfirmed) {
        this.miServicioPartido.eliminarPartido(idPartido).subscribe(
          data => {
            Swal.fire({
              icon: 'success',
              title: 'Partido eliminado',
              showConfirmButton: true
            })
    
            this.buscarPartido();
    
          }
          );
        }
      })    
    }
  
  }