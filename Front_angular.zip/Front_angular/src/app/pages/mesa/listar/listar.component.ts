import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import Swal from 'sweetalert2';
import { MesaService } from '../../../servicios/mesa.service';

@Component({
  selector: 'ngx-listar',
  templateUrl: './listar.component.html',
  styleUrls: ['./listar.component.scss']
})
export class ListarComponent implements OnInit {

  nombreColumnas = ["numero", "cantidad_inscritos", "Opciones"];
  listadoMesa = [];

  constructor(private miServicioMesa: MesaService,
    private router: Router) { }

  ngOnInit(): void {
    this.buscarMesa();
  }

  buscarMesa() {
    this.miServicioMesa.buscarMesa().subscribe(
      data => {
        this.listadoMesa = data;
      }
    );
  }

  crearMesa(){
    this.router.navigateByUrl("pages/mesa/crear");
  }

  actualizarMesa(idMesa: string) {
    console.log("editando"+idMesa)
    this.router.navigateByUrl("pages/mesa/actualizar/"+idMesa);
  }

  eliminarMesa(idMesa: string) {
    Swal.fire({
      title: 'Eliminar MESA',
      text: "Seguro que desea eliminar el mesa?",
      icon: 'warning',
      showCancelButton: true,
      confirmButtonColor: '#276DD1',
      cancelButtonColor: '#d33',
      confirmButtonText: 'Si, eliminar!'
    }).then((result) => {
      if (result.isConfirmed) {
        this.miServicioMesa.eliminarMesa(idMesa).subscribe(
  
          data => {
            Swal.fire({
              icon: 'success',
              title: 'Mesa eliminada',
              showConfirmButton: true
            })
    
            this.buscarMesa();
    
          }
        );
      }
    })    
  }
}