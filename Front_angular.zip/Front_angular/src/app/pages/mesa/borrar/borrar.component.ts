import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'ngx-borrar',
  templateUrl: './borrar.component.html',
  styleUrls: ['./borrar.component.scss']
})
export class BorrarComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
