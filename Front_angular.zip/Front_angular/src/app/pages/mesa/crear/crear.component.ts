import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import Swal from 'sweetalert2';
import { Mesa } from '../../../modelos/mesa.model';
import { MesaService } from '../../../servicios/mesa.service';


@Component({
  selector: 'ngx-crear',
  templateUrl: './crear.component.html',
  styleUrls: ['./crear.component.scss']
})
export class CrearComponent implements OnInit {
  modoCreacion: boolean = true;
  intentoEnvio: boolean = false;
  
  infoMesa: Mesa = {
    /*_id:"",*/
    numero: "",
    cantidad_inscritos: ""
  }
  router: any;

  constructor(private miServicioMesa: MesaService,
    private rutaActual: ActivatedRoute) { }

  ngOnInit(): void {
    
    if(this.rutaActual.snapshot.params.id_mesa){
      this.modoCreacion = false;
      this.miServicioMesa.buscarMesaId(this.rutaActual.snapshot.params.id_mesa)
      .subscribe(
        data=>{
          this.infoMesa=data;}
          );
    } else {
      this.modoCreacion = true;
    }
  }

  buscarMesa(idMesa: string) {
    this.miServicioMesa.buscarMesaId(idMesa)
    .subscribe(
      data => {
        this.infoMesa = data;
      }
    );
  }

  actualizarMesa() {
    if(this.validarCampos()) {
      this.miServicioMesa.actualizarMesa(this.infoMesa)
      .subscribe(
        data => {
          Swal.fire({
            icon: 'success',
            title: 'Mesa Actualizada!',
            showConfirmButton: true
          })

          this.router.navigateByUrl("pages/mesa/listar");
        }
      );
    }
  }

  crearMesa() {
    if(this.validarCampos()) {
      this.miServicioMesa.crearMesa(this.infoMesa)
      .subscribe(
        _data => {
          Swal.fire({
            icon: 'success',
            title: 'Mesa Creado!',
            showConfirmButton: true
          })

          this.router.navigateByUrl("pages/mesa/listar");
        }
      );
    }    
  }

  validarCampos(): boolean {
    this.intentoEnvio = true;
    if(this.infoMesa.numero == "" || this.infoMesa.cantidad_inscritos == "") 
    {
      return false;
    } else {
      return true;
    }
  }

}