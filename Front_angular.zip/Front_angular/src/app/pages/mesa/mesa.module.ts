import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { MesaRoutingModule } from './mesa-routing.module';
import { NbCardModule } from '@nebular/theme';
import { FormsModule } from '@angular/forms';
import { ListarComponent } from './listar/listar.component';
import { CrearComponent } from './crear/crear.component';
import { BorrarComponent } from './borrar/borrar.component';



@NgModule({
  declarations: [
    ListarComponent,
    CrearComponent,
    BorrarComponent
   
  ],
  imports: [
    CommonModule,
    MesaRoutingModule,
    NbCardModule,
    FormsModule
  ]
})
export class MesaModule { }
