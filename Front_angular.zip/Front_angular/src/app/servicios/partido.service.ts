import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { environment } from '../../environments/environment';
import { Partido } from '../modelos/partido.model';

@Injectable({
  providedIn: 'root'
})
export class PartidoService {

  constructor(private http:HttpClient) { }

  buscarPartido(): Observable<Partido[]>{
    return this.http.get<Partido[]>(`${environment.url_api_gateway}/Partido`);
  }
  buscarPartidoId(idPartido:String): Observable<Partido>{
    return this.http.get<Partido>(`${environment.url_api_gateway}/Partido/${idPartido}`);
  }
  crearPartido(infoPartido:Partido): Observable<Partido>{
    return this.http.post<Partido>(`${environment.url_api_gateway}/Partido`,infoPartido );
  }
  actualizarPartido(infoPartido:Partido): Observable<Partido>{
    return this.http.put<Partido>(`${environment.url_api_gateway}/Partido`,infoPartido);
    
  }

  eliminarPartido(idPartido:string){
     return this.http.delete(`${environment.url_api_gateway}/Partido/${idPartido}`);
  }

}
