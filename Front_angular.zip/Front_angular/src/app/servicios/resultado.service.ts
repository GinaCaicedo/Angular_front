import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { environment } from '../../environments/environment';
import { Resultado } from '../modelos/resultado.model';

@Injectable({
  providedIn: 'root'
})
export class ResultadoService {

  constructor(private http:HttpClient) { }

  buscarResultado(): Observable<Resultado[]>{
    return this.http.get<Resultado[]>(`${environment.url_api_gateway}/Resultado`);
  }
  buscarResultadoId(idResultado:String): Observable<Resultado>{
    return this.http.get<Resultado>(`${environment.url_api_gateway}/Eesultado/${idResultado}`);
  }
  crearResultado(infoResultado:Resultado): Observable<Resultado>{
    return this.http.post<Resultado>(`${environment.url_api_gateway}/Resultado/Mesa/${infoResultado.mesa._id}/Candidato/${infoResultado.candidato._id}`,infoResultado );
  }
  actualizarResultado(infoResultado:Resultado): Observable<Resultado>{
    return this.http.put<Resultado>(`${environment.url_api_gateway}/Resultado`,infoResultado);
    
  }

  eliminarResultado(idResultado:string){
    return this.http.delete(`${environment.url_api_gateway}/Resultado/${idResultado}`);
  }
}
